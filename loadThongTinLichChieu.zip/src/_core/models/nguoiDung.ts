export class nguoiDung {

    public taiKhoan:string;
    public matKhau:string;
    public email:string;
    public soDt:string;
    public maNhom:string = 'GP01';
    public maLoaiNguoiDung:string = 'KhachHang';
    public hoTen:string = ''
    constructor () {
        
    }
}