export const domain = 'https://movie0706.cybersoft.edu.vn';
export const userLogin = 'userLogin';
export const accessToken = 'accessToken';



