import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { QuanLyPhimService } from 'src/_core/services/quan-ly-phim.service';

@Component({
  selector: 'app-booking-ticket',
  template: `
    <span>{{thongTinPhongVe.thongTinPhim?.tenPhim}}</span>
  `,
  styleUrls: ['./booking-ticket.component.scss']
})
export class BookingTicketComponent implements OnInit {

  maLichChieu:number = 0;
  thongTinPhongVe:any = {}
  constructor(private atv:ActivatedRoute,private qlyPhimService:QuanLyPhimService) { }

  async ngOnInit() {
    //Lấy dữ liệu từ url về (maLichChieu)

    let param:any = await this.atv.params.pipe();

    this.maLichChieu = param.value.maLichChieu;

    //Gọi service lấy giá trị từ api về
    this.qlyPhimService.layThongTinPhongVe(this.maLichChieu).subscribe((res)=>{
      this.thongTinPhongVe = res;
      console.log(this.thongTinPhongVe)
    },err=>{
      console.log(err);
    })


  }




}
